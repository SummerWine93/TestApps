//
//  Slide2ContentViewController.h
//  SwissPlanner
//
//  Created by User on 4/27/16.
//  Copyright © 2016 Elena Baoychuk. All rights reserved.
//

#import "PageContentViewController.h"

@interface Slide2ContentViewController : PageContentViewController

@property (weak, nonatomic) IBOutlet UILabel *block90label;
@property (weak, nonatomic) IBOutlet UILabel *block9label;
@property (weak, nonatomic) IBOutlet UILabel *block1label;

@end
