//
//  SideMenuTableViewController.h
//  SwissPlanner
//
//  Created by User on 4/11/16.
//  Copyright © 2016 Elena Baoychuk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SideMenuTableViewController : UITableViewController

@property (strong, nonatomic) IBOutletCollection(UILabel ) NSArray * titleLabel;

@end
