//
//  AppDelegate.h
//  SwissPlanner
//
//  Created by User on 4/10/16.
//  Copyright © 2016 Elena Baoychuk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property BOOL restrictRotation;

@end

