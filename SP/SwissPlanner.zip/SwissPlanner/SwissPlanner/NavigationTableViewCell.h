//
//  NavigationTableViewCell.h
//  SwissPlanner
//
//  Created by User on 5/2/16.
//  Copyright © 2016 Elena Baoychuk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationTableViewCell : UITableViewCell

@property (nonatomic, assign) IBOutlet UIImage *cellImage;

@end
